select count(distinct(city)) from station;
